package com.neo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MMADApplication {

	public static void main(String[] args) {
		SpringApplication.run(MMADApplication.class, args);
	}
}
