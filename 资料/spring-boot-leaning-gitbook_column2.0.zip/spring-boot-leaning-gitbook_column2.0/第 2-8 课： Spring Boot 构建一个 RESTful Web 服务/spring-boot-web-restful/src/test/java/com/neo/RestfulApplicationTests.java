
package com.neo;



import org.junit.Test;

public class RestfulApplicationTests {

	@Test
	public void test() {
	}

}
