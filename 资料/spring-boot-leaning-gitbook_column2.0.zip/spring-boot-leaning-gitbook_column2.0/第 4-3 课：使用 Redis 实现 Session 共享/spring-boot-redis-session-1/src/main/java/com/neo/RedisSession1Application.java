package com.neo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedisSession1Application {

	public static void main(String[] args) {
		SpringApplication.run(RedisSession1Application.class, args);
	}
}
